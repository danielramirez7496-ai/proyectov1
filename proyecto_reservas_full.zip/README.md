# Sistema de Reservas - Microservicios (Lista para desplegar)

Este repositorio contiene un proyecto de ejemplo **Sistema de Reservas** basado en microservicios.
Incluye los siguientes servicios:
- ms-clientes (5001) : registro/login de clientes (emite JWT)
- ms-reservas (5002)  : CRUD de reservas (valida JWT)
- ms-mesas (5003)    : disponibilidad de mesas
- ms-notificaciones (5004) : notificaciones simuladas
- api-gateway (5000) : gateway que unifica las rutas

## Estructura
```
(lista de carpetas)
```

## Requisitos
- Docker
- docker-compose (opcional)
- Minikube (opcional) o Kubernetes
- kubectl
- curl o Postman

## Cómo usar (rápido)
# 1) Construir imágenes:
docker build -t ms-clientes:1 ms-clientes/
docker build -t ms-mesas:1 ms-mesas/
docker build -t ms-notificaciones:1 ms-notificaciones/
docker build -t ms-reservas:1 ms-reservas/
docker build -t api-gateway:1 api-gateway/

# 2) Levantar con docker-compose (local):
docker-compose up --build

# 3) O usar Minikube:
minikube start
minikube image load ms-clientes:1
minikube image load ms-mesas:1
minikube image load ms-notificaciones:1
minikube image load ms-reservas:1
minikube image load api-gateway:1

kubectl apply -f k8s/

minikube service api-gateway --url

## Endpoints (gateway)
POST /register       -> registrar cliente
POST /login          -> login, devuelve token
POST /reservar       -> crear reserva (en header Authorization: Bearer <token>)
GET  /mis-reservas/<email> -> listar reservas

