from flask import Flask, request, jsonify

app = Flask(__name__)

mesas = {
    1: {"capacidad": 4, "ocupadas": []},
    2: {"capacidad": 2, "ocupadas": []},
    3: {"capacidad": 6, "ocupadas": []}
}

@app.route("/list", methods=["GET"])
def listar_mesas():
    return jsonify({"mesas": mesas}), 200

@app.route("/disponible/<int:mesa_id>/<fecha>/<hora>", methods=["GET"])
def disponible(mesa_id, fecha, hora):
    m = mesas.get(mesa_id)
    if not m:
        return jsonify({"error":"Mesa no existe"}), 404
    ocupado = any(b == f"{fecha} {hora}" for b in m["ocupadas"])
    return jsonify({"disponible": not ocupado}), 200

@app.route("/ocupar", methods=["POST"])
def ocupar():
    data = request.get_json() or {}
    mesa_id = data.get("mesa_id")
    fecha = data.get("fecha")
    hora = data.get("hora")
    if mesa_id not in mesas:
        return jsonify({"error":"Mesa no existe"}), 404
    mesas[mesa_id]["ocupadas"].append(f"{fecha} {hora}")
    return jsonify({"mensaje":"Mesa ocupada"}), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5003)
