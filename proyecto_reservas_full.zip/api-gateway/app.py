from flask import Flask, request, jsonify
import requests
import os

app = Flask(__name__)

URL_CLIENTES = os.environ.get("URL_CLIENTES","http://ms-clientes:5001")
URL_RESERVAS = os.environ.get("URL_RESERVAS","http://ms-reservas:5002")
URL_AUTH = os.environ.get("URL_AUTH","http://ms-clientes:5001")

@app.route("/register", methods=["POST"])
def register():
    r = requests.post(f"{URL_CLIENTES}/register", json=request.get_json())
    return (r.text, r.status_code, r.headers.items())

@app.route("/login", methods=["POST"])
def login():
    r = requests.post(f"{URL_CLIENTES}/login", json=request.get_json())
    return (r.text, r.status_code, r.headers.items())

@app.route("/reservar", methods=["POST"])
def reservar():
    token = request.headers.get("Authorization")
    headers = {"Authorization": token} if token else {}
    r = requests.post(f"{URL_RESERVAS}/crear", json=request.get_json(), headers=headers, timeout=5)
    return (r.text, r.status_code, r.headers.items())

@app.route("/mis-reservas/<email>", methods=["GET"])
def mis_reservas(email):
    r = requests.get(f"{URL_RESERVAS}/listar/{email}")
    return (r.text, r.status_code, r.headers.items())

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
