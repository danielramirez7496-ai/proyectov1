from flask import Flask, request, jsonify
import requests
import jwt
import os

app = Flask(__name__)
SECRET_KEY = os.environ.get("SECRET_KEY","CAMBIA_ESTA_CLAVE_POR_SEGURIDAD")

reservas = []
next_id = 1

def validar_token(auth_header):
    if not auth_header:
        return False, "No Authorization header"
    try:
        parts = auth_header.split()
        if parts[0].lower() != "bearer":
            return False, "Invalid header"
        token = parts[1]
        payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        return True, payload.get("sub")
    except Exception as e:
        return False, str(e)

@app.route("/crear", methods=["POST"])
def crear():
    global next_id
    auth = request.headers.get("Authorization")
    ok, user_or_err = validar_token(auth)
    if not ok:
        return jsonify({"error":"No autorizado", "detalle": user_or_err}), 401

    data = request.get_json() or {}
    fecha = data.get("fecha")
    hora = data.get("hora")
    mesa_id = data.get("mesa_id")

    if not fecha or not hora or mesa_id is None:
        return jsonify({"error":"Faltan datos (fecha,hora,mesa_id)"}), 400

    try:
        r = requests.get(f"http://ms-mesas:5003/disponible/{mesa_id}/{fecha}/{hora}", timeout=2)
        if r.status_code != 200 or not r.json().get("disponible", False):
            return jsonify({"error":"Mesa no disponible"}), 400
    except Exception as e:
        return jsonify({"error":"Error consultando ms-mesas", "detalle": str(e)}), 500

    reserva = {"id": next_id, "email": user_or_err, "fecha": fecha, "hora": hora, "mesa_id": mesa_id}
    reservas.append(reserva)
    next_id += 1

    try:
        requests.post("http://ms-notificaciones:5004/notify", json={"email": user_or_err, "mensaje": f"Reserva confirmada: {reserva}"}, timeout=1)
    except:
        pass

    return jsonify({"mensaje":"Reserva creada", "reserva": reserva}), 201

@app.route("/listar/<email>", methods=["GET"])
def listar(email):
    user_res = [r for r in reservas if r["email"] == email]
    return jsonify({"reservas": user_res}), 200

@app.route("/cancelar/<int:reserva_id>", methods=["DELETE"])
def cancelar(reserva_id):
    global reservas
    found = [r for r in reservas if r["id"] == reserva_id]
    if not found:
        return jsonify({"error":"Reserva no encontrada"}), 404
    reservas = [r for r in reservas if r["id"] != reserva_id]
    return jsonify({"mensaje":"Reserva cancelada"}), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002)
