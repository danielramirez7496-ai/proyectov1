from flask import Flask, request, jsonify
import jwt
import datetime
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY','CAMBIA_ESTA_CLAVE_POR_SEGURIDAD')

clientes = {}  # email -> {nombre, telefono, password}

def generar_token(email):
    payload = {
        "sub": email,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=6)
    }
    token = jwt.encode(payload, app.config['SECRET_KEY'], algorithm='HS256')
    if isinstance(token, bytes):
        token = token.decode('utf-8')
    return token

@app.route("/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    email = data.get("email")
    nombre = data.get("nombre")
    password = data.get("password")
    telefono = data.get("telefono","")
    if not email or not nombre or not password:
        return jsonify({"error":"Faltan datos (email,nombre,password)"}), 400
    if email in clientes:
        return jsonify({"error":"Cliente ya existe"}), 400
    clientes[email] = {"nombre": nombre, "password": password, "telefono": telefono}
    return jsonify({"mensaje":"Cliente registrado"}), 201

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    email = data.get("email")
    password = data.get("password")
    cliente = clientes.get(email)
    if not cliente or cliente.get("password") != password:
        return jsonify({"error":"Credenciales incorrectas"}), 401
    token = generar_token(email)
    return jsonify({"token": token}), 200

@app.route("/info/<email>", methods=["GET"])
def info(email):
    cliente = clientes.get(email)
    if not cliente:
        return jsonify({"error":"No encontrado"}), 404
    return jsonify({"email": email, "nombre": cliente["nombre"], "telefono": cliente["telefono"]})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
