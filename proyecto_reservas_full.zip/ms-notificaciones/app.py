from flask import Flask, request, jsonify

app = Flask(__name__)
log = []

@app.route("/notify", methods=["POST"])
def notify():
    data = request.get_json() or {}
    email = data.get("email")
    mensaje = data.get("mensaje")
    log.append({"email": email, "mensaje": mensaje})
    print(f"[NOTIFICACIÓN] a {email}: {mensaje}")
    return jsonify({"mensaje":"Notificación encolada"}), 200

@app.route("/log", methods=["GET"])
def get_log():
    return jsonify({"log": log}), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5004)
